import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import ToDOForm from './ToDOForm';

export default function CustomApp() {
  const [tasks, setTasks] = useState([]);

  const addTask = (task) => {
    setTasks([...tasks, task]);
  };

  return (
    <View style={styles.container}>
      <ToDoForm addTask={addTask} /> 
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
