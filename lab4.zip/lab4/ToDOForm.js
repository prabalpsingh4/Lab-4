import React, { useState } from 'react';
import { TextInput, Button, StyleSheet, View, Text } from 'react-native';

function ToDoForm({ addTask }) {
    const [taskText, setTaskText] = useState('');

    return (
        <View style={styles.container}>
            <TextInput
                style={styles.input}
                placeholder="Enter a new task..."
                onChangeText={(text) => setTaskText(text)}
                value={taskText}
                placeholderTextColor="#888"
            />
            <Button
                title="Add"
                color="#4CAF50"
                onPress={() => {
                    addTask(taskText);
                    setTaskText('');
                }}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        paddingHorizontal: 20,
        paddingVertical: 10,
        backgroundColor: '#f0f0f0',
        borderRadius: 10,
        marginHorizontal: 20,
        marginVertical: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 10,
        marginBottom: 10,
        borderRadius: 5,
        color: '#333',
        backgroundColor: '#fff',
    },
});

export default ToDoForm;
